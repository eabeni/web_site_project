Clazz.declarePackage ("J.awtjs.swing");
Clazz.declareInterface (J.awtjs.swing, "TableCellRenderer");
