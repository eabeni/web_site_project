Clazz.declarePackage ("J.awtjs.swing");
c$ = Clazz.declareType (J.awtjs.swing, "SwingConstants");
Clazz.defineStatics (c$,
"LEFT", 2,
"CENTER", 0,
"RIGHT", 4);
