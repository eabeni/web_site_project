Clazz.declarePackage ("J.awtjs.swing");
Clazz.load (["J.awtjs.swing.JComponent"], "J.awtjs.swing.JComponentImp", null, function () {
c$ = Clazz.declareType (J.awtjs.swing, "JComponentImp", J.awtjs.swing.JComponent);
Clazz.overrideMethod (c$, "toHTML", 
function () {
return null;
});
});
