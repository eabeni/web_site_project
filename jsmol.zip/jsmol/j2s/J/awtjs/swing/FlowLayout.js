Clazz.declarePackage ("J.awtjs.swing");
Clazz.load (["javajs.awt.LayoutManager"], "J.awtjs.swing.FlowLayout", null, function () {
c$ = Clazz.declareType (J.awtjs.swing, "FlowLayout", javajs.awt.LayoutManager);
});
