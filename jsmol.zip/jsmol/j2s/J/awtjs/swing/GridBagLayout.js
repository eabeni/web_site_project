Clazz.declarePackage ("J.awtjs.swing");
Clazz.load (["javajs.awt.LayoutManager"], "J.awtjs.swing.GridBagLayout", null, function () {
c$ = Clazz.declareType (J.awtjs.swing, "GridBagLayout", javajs.awt.LayoutManager);
});
