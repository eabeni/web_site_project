Clazz.declarePackage ("J.api");
Clazz.load (["javajs.api.js.J2SObjectInterface"], "J.api.JmolToJSmolInterface", null, function () {
Clazz.declareInterface (J.api, "JmolToJSmolInterface", javajs.api.js.J2SObjectInterface);
});
